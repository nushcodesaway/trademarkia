"use client"

import { useEffect, useState } from "react"
import { db } from "../lib/firebase"
import { collection, doc, setDoc, onSnapshot } from "firebase/firestore"

const rows = 20
const cols = 10

export default function Spreadsheet() {

  const [cells, setCells] = useState<{[key:string]:string}>({})

  useEffect(()=>{

    const unsubscribe = onSnapshot(collection(db,"cells"),(snapshot)=>{

      const data:any = {}

      snapshot.forEach((doc)=>{
        data[doc.id] = doc.data().value
      })

      setCells(data)

    })

    return ()=>unsubscribe()

  },[])

  const updateCell = async (id:string,value:string)=>{

    setCells(prev=>({
      ...prev,
      [id]:value
    }))

    await setDoc(doc(db,"cells",id),{
      value:value
    })

  }

  return (

    <div>

      {Array.from({length:rows}).map((_,r)=>(
        <div key={r} style={{display:"flex"}}>

          {Array.from({length:cols}).map((_,c)=>{

            const id = `${String.fromCharCode(65+c)}${r+1}`

            return(
              <input
                key={id}
                value={cells[id] || ""}
                onChange={(e)=>updateCell(id,e.target.value)}
                style={{
                  border:"1px solid gray",
                  width:"80px",
                  height:"30px",
                  textAlign:"center"
                }}
              />
            )

          })}

        </div>
      ))}

    </div>

  )
}