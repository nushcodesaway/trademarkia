import Link from "next/link"

export default function Home() {
  return (
    <div className="flex flex-col items-center justify-center h-screen gap-6">
      <h1 className="text-3xl font-bold">Trademarkia Spreadsheet</h1>

      <Link
        href="/doc/demo"
        className="bg-blue-600 text-white px-6 py-3 rounded"
      >
        Open Spreadsheet
      </Link>
    </div>
  )
}