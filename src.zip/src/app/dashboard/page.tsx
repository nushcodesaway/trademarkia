"use client"

import { collection, addDoc, onSnapshot } from "firebase/firestore"
import { db } from "@/lib/firebase"
import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"

export default function Dashboard() {
  const [docs, setDocs] = useState<any[]>([])
  const router = useRouter()

  useEffect(() => {
    const unsub = onSnapshot(collection(db, "documents"), (snap) => {
      setDocs(snap.docs.map(d => ({ id: d.id, ...d.data() })))
    })

    return () => unsub()
  }, [])

  const createDoc = async () => {
    const doc = await addDoc(collection(db, "documents"), {
      title: "Untitled Sheet",
      createdAt: Date.now()
    })

    router.push(`/doc/${doc.id}`)
  }

  return (
    <div className="p-10">
      <button
        onClick={createDoc}
        className="bg-blue-500 text-white px-4 py-2 rounded"
      >
        New Sheet
      </button>

      <div className="mt-6">
        {docs.map(doc => (
          <div
            key={doc.id}
            className="p-4 border cursor-pointer"
            onClick={() => router.push(`/doc/${doc.id}`)}
          >
            {doc.title}
          </div>
        ))}
      </div>
    </div>
  )
}