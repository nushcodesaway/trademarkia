"use client"

import Spreadsheet from "../../../components/Spreadsheet"

export default function DocPage() {
  return (
    <div style={{ padding: "20px" }}>
      <Spreadsheet />
    </div>
  )
}