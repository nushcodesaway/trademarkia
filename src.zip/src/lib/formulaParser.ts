export function evaluate(value: string, cells: any) {
  if (!value.startsWith("=")) return value

  if (value.includes("+")) {
    const [a, b] = value.slice(1).split("+")
    return Number(cells[a]) + Number(cells[b])
  }

  return value
}