import { initializeApp } from "firebase/app"
import { getFirestore } from "firebase/firestore"

const firebaseConfig = {
  apiKey: "AIzaSyCZ05xwhxJ8G8KCGft05Bl37VBsqagHfUc",
  authDomain: "trademarkiaspreadsheet.firebaseapp.com",
  projectId: "trademarkiaspreadsheet",
  storageBucket: "trademarkiaspreadsheet.firebasestorage.app",
  messagingSenderId: "286343033419",
  appId: "1:286343033419:web:c83447cab712522bc4d3ce"
}

const app = initializeApp(firebaseConfig)

export const db = getFirestore(app)